"""
Given a file that contains a list of numbers (one per line) write a program to print out
the 5 most commonly occurring numbers, one per line, without whitespaces and in descending order of frequency.
"""

filename_numbers = 'numbers.txt'
